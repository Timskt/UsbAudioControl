using UsbAudioControl;

Console.WriteLine("=== 音频静音控制测试 ===\n");

// 显示可用的控制方案
Console.WriteLine("可用控制方案:");
var controllers = AudioControllerFactory.GetAvailableControllers();
foreach (var (type, desc, available) in controllers)
{
    Console.WriteLine($"  [{(available ? "Y" : "N")}] {type}: {desc}");
}
Console.WriteLine();

// 枚举所有设备
Console.WriteLine("=== 枚举音频输入设备 ===");
var devices = AudioControllerFactory.EnumerateAllDevices();
Console.WriteLine($"找到 {devices.Count} 个设备:\n");

for (int i = 0; i < devices.Count; i++)
{
    var d = devices[i];
    Console.WriteLine($"[{i}] {d.Name ?? "Unknown"}");
    Console.WriteLine($"    类型: {d.ControllerType}");
    Console.WriteLine($"    DeviceId: {d.DeviceId}");
    if (d.VendorId != 0)
    {
        Console.WriteLine($"    VID:PID: 0x{d.VendorId:X4}:0x{d.ProductId:X4}");
    }
    Console.WriteLine($"    支持静音: {d.SupportsMute}");
    Console.WriteLine($"    支持音量: {d.SupportsVolume}");
    Console.WriteLine();
}

// 使用最佳方案测试
Console.WriteLine("=== 测试最佳方案 ===");
// using var controller = AudioControllerFactory.CreateBest();
using var controller = AudioControllerFactory.CreateUsbAudio();
Console.WriteLine($"控制器类型: {controller.GetType().Name}");

if (!controller.ConnectToFirst())
{
    Console.WriteLine("连接失败！没有找到可用的音频输入设备。");
    return;
}

Console.WriteLine($"已连接: {controller.ConnectedDevice?.Name ?? "Unknown"}\n");

// 读取当前状态
var currentMute = controller.GetMute();
var currentVolume = controller.GetVolume();
Console.WriteLine($"当前静音状态: {(currentMute == true ? "静音" : currentMute == false ? "未静音" : "未知")}");
Console.WriteLine($"当前音量: {(currentVolume.HasValue ? $"{currentVolume.Value:P0}" : "未知")}");

// 测试静音切换
Console.WriteLine("\n测试切换静音...");
var newMute = controller.ToggleMute();
Console.WriteLine($"切换后静音状态: {(newMute == true ? "静音" : newMute == false ? "未静音" : "未知")}");

// 恢复原来的状态
if (currentMute.HasValue && newMute != currentMute)
{
    controller.SetMute(currentMute.Value);
    Console.WriteLine($"已恢复原静音状态: {(currentMute.Value ? "静音" : "未静音")}");
}

Console.WriteLine("\n测试完成！");
