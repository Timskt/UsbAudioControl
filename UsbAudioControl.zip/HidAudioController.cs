using HidLibrary;

namespace UsbAudioControl;

/// <summary>
/// HID 音频设备控制器
/// 使用 HidLibrary 控制设备的物理按钮和 LED 指示灯
/// 
/// 设备信息 (Hamedal Speak A20):
/// - VID: 0x1FC9, PID: 0x826B
/// - Usage Page: 0x0081 (Vendor Defined)
/// - Usage: 0x0082
/// - Report ID: 5
/// - 报告长度: 1024 字节
/// </summary>
public class HidAudioController : IAudioMuteController
{
    private HidDevice? _device;
    private HidDeviceInfo? _connectedDeviceInfo;
    private bool _disposed;
    private bool _isMonitoring;
    private bool _lastMuteState;
    private float _lastVolume;
    private readonly object _lock = new();

    // 设备常量
    private const int VendorId = 0x1FC9;
    private const int ProductId = 0x826B;
    private const byte ReportId = 3;  // 确认的 Report ID
    private const byte MuteOnData = 0x05;   // 静音
    private const byte MuteOffData = 0x01;  // 取消静音
    private const int ReportLength = 1024;

    public AudioDeviceInfo? ConnectedDevice => _connectedDeviceInfo?.ToAudioDeviceInfo();
    public bool IsConnected => _device != null && _device.IsConnected;
    public bool SupportsMute => true;
    public bool SupportsVolume => false;
    public bool SupportsLed => true;

    public event EventHandler<AudioStateChangedEventArgs>? StateChanged;
    public event EventHandler<PhysicalButtonEventArgs>? PhysicalButtonPressed;

    /// <summary>
    /// 查找所有 HID 音频设备
    /// </summary>
    public static List<HidDeviceInfo> FindAllHidAudioDevices()
    {
        var devices = new List<HidDeviceInfo>();
        
        // 查找指定 VID/PID 的设备，只选择支持输出的接口
        var hidDevices = HidDevices.Enumerate(VendorId, ProductId)
            .Where(d => d.Capabilities.OutputReportByteLength > 0);
        
        foreach (var device in hidDevices)
        {
            try
            {
                var info = new HidDeviceInfo
                {
                    VendorId = (int)device.Attributes.VendorId,
                    ProductId = (int)device.Attributes.ProductId,
                    ProductName = device.Description ?? "Hamedal Speak A20",
                    DevicePath = device.DevicePath,
                    UsagePage = (ushort)device.Capabilities.UsagePage,
                    Usage = (ushort)device.Capabilities.Usage,
                    InputReportLength = device.Capabilities.InputReportByteLength,
                    OutputReportLength = device.Capabilities.OutputReportByteLength,
                    FeatureReportLength = device.Capabilities.FeatureReportByteLength
                };
                
                devices.Add(info);
            }
            finally
            {
                device.CloseDevice();
            }
        }
        
        return devices;
    }

    public IReadOnlyList<AudioDeviceInfo> EnumerateDevices()
    {
        return FindAllHidAudioDevices()
            .Select(d => d.ToAudioDeviceInfo())
            .ToList();
    }

    public bool Connect(AudioDeviceInfo device)
    {
        return ConnectByVidPid(device.VendorId, device.ProductId);
    }

    public bool ConnectByVidPid(int vendorId, int productId)
    {
        Disconnect();
        
        var devices = HidDevices.Enumerate(vendorId, productId)
            .Where(d => d.Capabilities.OutputReportByteLength > 0)
            .ToList();
        
        Console.WriteLine($"找到 {devices.Count} 个支持输出的接口");
        for (int i = 0; i < devices.Count; i++)
        {
            Console.WriteLine($"  [{i}] Usage Page: 0x{devices[i].Capabilities.UsagePage:X4}, Usage: 0x{devices[i].Capabilities.Usage:X4}");
        }
        
        // 选择第二个接口（索引1），这是之前测试确认有效的接口
        int selectedIndex = devices.Count > 1 ? 1 : 0;
        Console.WriteLine($"选择接口 {selectedIndex}");
        
        _device = devices[selectedIndex];
        
        if (_device == null)
            return false;
        
        _device.OpenDevice();
        
        if (!_device.IsConnected)
        {
            Console.WriteLine("设备连接失败!");
            _device.Dispose();
            _device = null;
            return false;
        }
        
        Console.WriteLine("设备已连接");
        
        _connectedDeviceInfo = new HidDeviceInfo
        {
            VendorId = (int)_device.Attributes.VendorId,
            ProductId = (int)_device.Attributes.ProductId,
            ProductName = _device.Description ?? "Hamedal Speak A20",
            DevicePath = _device.DevicePath,
            UsagePage = (ushort)_device.Capabilities.UsagePage,
            Usage = (ushort)_device.Capabilities.Usage,
            InputReportLength = _device.Capabilities.InputReportByteLength,
            OutputReportLength = _device.Capabilities.OutputReportByteLength
        };
        
        // 初始化状态
        _lastMuteState = GetMute() ?? false;
        
        return true;
    }

    public bool ConnectByVidPid(string vidPid)
    {
        if (string.IsNullOrEmpty(vidPid))
            return false;
        
        var parts = vidPid.Split(':');
        if (parts.Length != 2)
            return false;
        
        try
        {
            int vid = Convert.ToInt32(parts[0], 16);
            int pid = Convert.ToInt32(parts[1], 16);
            return ConnectByVidPid(vid, pid);
        }
        catch
        {
            return false;
        }
    }

    public bool ConnectToFirst()
    {
        return ConnectByVidPid(VendorId, ProductId);
    }
    
    /// <summary>
    /// 通过设备路径连接
    /// </summary>
    public bool ConnectByPath(string? devicePath)
    {
        if (string.IsNullOrEmpty(devicePath))
            return false;
        
        Disconnect();
        
        var allDevices = HidDevices.Enumerate()
            .Where(d => d.Capabilities.OutputReportByteLength > 0);
        _device = allDevices.FirstOrDefault(d => d.DevicePath == devicePath);
        
        if (_device == null)
            return false;
        
        _device.OpenDevice();
        
        if (!_device.IsConnected)
        {
            _device.Dispose();
            _device = null;
            return false;
        }
        
        _connectedDeviceInfo = new HidDeviceInfo
        {
            VendorId = (int)_device.Attributes.VendorId,
            ProductId = (int)_device.Attributes.ProductId,
            ProductName = _device.Description ?? "HID Audio Device",
            DevicePath = _device.DevicePath,
            UsagePage = (ushort)_device.Capabilities.UsagePage,
            Usage = (ushort)_device.Capabilities.Usage,
            InputReportLength = _device.Capabilities.InputReportByteLength,
            OutputReportLength = _device.Capabilities.OutputReportByteLength
        };
        
        _lastMuteState = GetMute() ?? false;
        
        return true;
    }

    public void Disconnect()
    {
        lock (_lock)
        {
            StopMonitoring();
            if (_device != null)
            {
                _device.CloseDevice();
                _device.Dispose();
                _device = null;
            }
            _connectedDeviceInfo = null;
        }
    }

    public bool SetMute(bool mute)
    {
        if (_device == null || !_device.IsConnected)
            return false;
        
        return SendMuteCommand(mute);
    }

    public bool? GetMute()
    {
        // HID 设备通常需要从设备读取状态
        // 这里返回缓存的状态
        return _lastMuteState;
    }

    public bool? ToggleMute()
    {
        var current = GetMute();
        if (current == null)
            return null;
        
        var newState = !current.Value;
        return SetMute(newState) ? newState : null;
    }

    public bool SetVolume(float volume)
    {
        return false;
    }

    public float? GetVolume()
    {
        return null;
    }

    /// <summary>
    /// 设置静音 LED 指示灯
    /// </summary>
    public bool SetMuteLed(bool muted)
    {
        return SendMuteCommand(muted);
    }

    /// <summary>
    /// 发送静音命令到设备
    /// 
    /// 协议 (已确认):
    /// - Report ID: 3
    /// - Data=0x05: 静音 (LED 亮)
    /// - Data=0x01: 取消静音 (LED 灭)
    /// </summary>
    private bool SendMuteCommand(bool mute)
    {
        if (_device == null || !_device.IsConnected)
            return false;
        
        try
        {
            var reportData = new byte[_device.Capabilities.OutputReportByteLength];
            reportData[0] = ReportId;
            reportData[1] = mute ? MuteOnData : MuteOffData;
            
            Console.WriteLine($"发送: Report ID={ReportId}, Data={(mute ? MuteOnData : MuteOffData):X2}");
            
            _device.Write(reportData);
            _lastMuteState = mute;
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"发送 HID 报告失败: {ex.Message}");
            return false;
        }
    }

    /// <summary>
    /// 发送原始 HID 报告
    /// </summary>
    public bool SendRawReport(byte[] data)
    {
        if (_device == null || !_device.IsConnected)
            return false;
        
        try
        {
            byte[] report = new byte[ReportLength];
            report[0] = ReportId;
            Array.Copy(data, 0, report, 1, Math.Min(data.Length, ReportLength - 1));
            
            return _device.Write(report);
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// 读取 HID 报告
    /// </summary>
    public byte[]? ReadReport(int timeoutMs = 100)
    {
        if (_device == null || !_device.IsConnected)
            return null;
        
        try
        {
            var report = _device.ReadReport(timeoutMs);
            if (report != null)
            {
                return report.Data;
            }
        }
        catch
        {
            // 忽略读取错误
        }
        
        return null;
    }

    public void StartMonitoring()
    {
        lock (_lock)
        {
            if (_device == null || !_device.IsConnected || _isMonitoring)
                return;
            
            _isMonitoring = true;
            _lastMuteState = GetMute() ?? false;
            
            // 使用 HidLibrary 的异步读取
            _device.MonitorDeviceEvents = true;
            _device.ReadReport(OnReportReceived);
        }
    }

    public void StopMonitoring()
    {
        lock (_lock)
        {
            if (!_isMonitoring)
                return;
            
            _isMonitoring = false;
            if (_device != null)
            {
                _device.MonitorDeviceEvents = false;
            }
        }
    }

    private void OnReportReceived(HidReport report)
    {
        if (!_isMonitoring || _device == null)
            return;
        
        try
        {
            // 解析报告数据
            ParseHidReport(report.Data);
            
            // 继续监听
            _device.ReadReport(OnReportReceived);
        }
        catch
        {
            // 忽略解析错误
        }
    }

    private void ParseHidReport(byte[] data)
    {
        if (data == null || data.Length < 2)
            return;
        
        // 尝试解析静音状态
        // 这需要根据实际协议调整
        if (data[0] == ReportId)
        {
            bool newMuteState = data[1] != 0;
            
            if (newMuteState != _lastMuteState)
            {
                _lastMuteState = newMuteState;
                
                PhysicalButtonPressed?.Invoke(this, new PhysicalButtonEventArgs
                {
                    ButtonType = PhysicalButtonType.Mute,
                    IsPressed = true,
                    NewMuteState = newMuteState
                });
                
                StateChanged?.Invoke(this, new AudioStateChangedEventArgs
                {
                    IsMuted = newMuteState,
                    Volume = _lastVolume,
                    Device = ConnectedDevice
                });
            }
        }
    }

    public void Dispose()
    {
        if (_disposed)
            return;
        
        Disconnect();
        _disposed = true;
    }
}

/// <summary>
/// HID 设备信息
/// </summary>
public class HidDeviceInfo
{
    public int VendorId { get; init; }
    public int ProductId { get; init; }
    public string? ProductName { get; init; }
    public string? DevicePath { get; init; }
    public ushort UsagePage { get; init; }
    public ushort Usage { get; init; }
    public int InputReportLength { get; init; }
    public int OutputReportLength { get; init; }
    public int FeatureReportLength { get; init; }
    
    public AudioDeviceInfo ToAudioDeviceInfo()
    {
        return new AudioDeviceInfo
        {
            Name = ProductName ?? $"HID Audio Device ({VendorId:X4}:{ProductId:X4})",
            DeviceId = DevicePath,
            VendorId = VendorId,
            ProductId = ProductId,
            ControllerType = AudioControllerType.HidAudio,
            SupportsMute = true,
            SupportsVolume = false
        };
    }
}